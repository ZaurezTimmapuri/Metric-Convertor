package com.example.metricconvert;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class HomeScreen extends AppCompatActivity {
    private final ImageButton time_button;

    public HomeScreen(ImageButton time_button) {
        this.time_button = time_button;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        ImageButton length_button = findViewById(R.id.image_button);
        ImageButton mass_button = findViewById(R.id.mass_button);
        ImageButton temperature_button = findViewById(R.id.temperature_button);


        temperature_button.setOnClickListener(v -> {
            Intent d = new Intent(HomeScreen.this,Time.class);
            startActivity(d);
        });

        time_button.setOnClickListener(v -> {
            Intent c = new Intent(HomeScreen.this,Time.class);
            startActivity(c);
        });

        mass_button.setOnClickListener(v -> {
            Intent b = new Intent(HomeScreen.this,Mass.class);
            startActivity(b);
        });


        length_button.setOnClickListener(v -> {
            Intent a = new Intent(HomeScreen.this,Length.class);
            startActivity(a);
        });

    }
}